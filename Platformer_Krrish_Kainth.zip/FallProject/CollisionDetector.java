public class CollisionDetector {

  int x;
  int y;
  int w;
  int h;
  int dx;
  int dy;
  static int maxX;
  static int maxY;

  public boolean collision(Obstacle[] levelObstacles) {
    for (Obstacle obs : levelObstacles) {
      if (collisionRight(obs) || collisionLeft(obs) ||
          collisionTop(obs) || collisionBottom(obs)) {
        return true;
      }
    }
    return false;
  }

  public boolean collision(Obstacle obs) {
    if (collisionRight(obs) || collisionLeft(obs) ||
        collisionTop(obs) || collisionBottom(obs)) {
      return true;
    }
    return false;
  }

  public boolean collisionRight(Obstacle obs) {
    if (x + w <= obs.x && x + w + dx >= obs.x + obs.dx
        && y + h >= obs.y && y <= obs.y + obs.h) {
      return true;
    }
    return false;
  }

  public boolean collisionLeft(Obstacle obs) {
    if (x >= obs.x + obs.w && x + dx <= obs.x + obs.w + obs.dx
        && y + h >= obs.y && y <= obs.y + obs.h) {
      return true;
    }
    return false;
  }

  public boolean collisionTop(Obstacle obs) {
    if (y + h <= obs.y && y + h + dy >= obs.y + obs.dy
        && x + w >= obs.x && x <= obs.x + obs.w) {
      return true;
    }
    return false;
  }

  public boolean collisionBottom(Obstacle obs) {
    if (y >= obs.y + obs.h && y + dy <= obs.y + obs.h + obs.dy
        && x + w >= obs.x && x <= obs.x + obs.w) {
      return true;
    }
    return false;
  }
}
