import java.awt.Graphics2D;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Image;

public class Obstacle {

  int x;
  int y;
  int w;
  int h;
  static int dx = -3;
  int dy = 0;
  boolean movingY = false;
  int T;
  int A;
  Color obsColor;

  public Obstacle() {}

  public Obstacle(int x, int y, int w, int h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }

  public void initGradColor() {
    this.obsColor = new Color((int) (200 - Math.exp(-0.001 * (this.x - 5000))), 75,
                              (int) Math.exp(-0.001 * (this.x - 5000)) + 50, 255);
  }

  public void display(Graphics2D gameGraphics, Game game) {
    gameGraphics.setColor(this.obsColor);
    gameGraphics.fillRect(this.x, this.y, this.w, this.h);
  }

  public void move() {
    this.x += this.dx;
    if (this.movingY) {
      updateDy();
    }
    this.y += this.dy;
  }

  public void updateDy() {
    this.dy = (int) (this.A * 2 * Math.PI / this.T *
              Math.cos(System.currentTimeMillis() * 2 * Math.PI / this.T));
  }
}
