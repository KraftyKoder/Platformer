import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Image;

public class PlayerPlatform extends CollisionDetector {

  int speed = 5;
  private Player player;
  int movementBoundY = this.maxY / 2;
  Color platformOutlineColor = new Color(200, 225, 10, 200);
  Color platformBodyColor = new Color(10, 150, 130, 200);

  public PlayerPlatform(int w, int h, Player player) {
    this.w = w;
    this.h = h;
    this.player = player;
  }

  public void display(Graphics2D gameGraphics, Game game) {
    gameGraphics.setColor(this.platformOutlineColor);
    gameGraphics.fillRect(this.x, this.y, this.w, this.h);
    gameGraphics.setColor(this.platformBodyColor);
    gameGraphics.fillRect(this.x + 3, this.y + 3, this.w - 6, this.h - 6);
  }

  public void move() {
    if (isOutOfBoundsLeft() && dx < 0) {
      dx = 0;
    }
    if (isOutOfBoundsRight() && dx > 0) {
      dx = 0;
    }
    if (isOutOfBoundsUp() && dy < 0) {
      dy = 0;
    }
    if (isOutOfBoundsDown() && dy > 0) {
      dy = 0;
    }
    updatePlayerMovement();
    this.x += dx;
    this.y += dy;
  }

  public void updatePlayerMovement() {
    if (!player.isJumping) {
      player.dx = dx;
      player.dy = dy;
    }
  }

  public void keyPressed(int button) {
    if (button == KeyEvent.VK_RIGHT || button == KeyEvent.VK_D) {
      dx = speed;
    }
    if (button == KeyEvent.VK_LEFT || button == KeyEvent.VK_A) {
      dx = -1 * speed;
    }
    if (button == KeyEvent.VK_UP || button == KeyEvent.VK_W) {
      dy = - 1 * speed;
    }
    if (button == KeyEvent.VK_DOWN || button == KeyEvent.VK_S) {
      dy = speed;
    }
    if (button == KeyEvent.VK_SPACE) {
      if (!player.isJumping) {
        player.jumpStartTime = System.currentTimeMillis();
        player.isJumping = true;
        player.jumpInitDy = dy - 7;
        this.speed = 7;
      }
    }
  }

  public void keyReleased(int button) {
    if (button == KeyEvent.VK_RIGHT || button == KeyEvent.VK_D ||
        button == KeyEvent.VK_LEFT || button == KeyEvent.VK_A) {
      dx = 0;
    }
    if (button == KeyEvent.VK_UP || button == KeyEvent.VK_W ||
        button == KeyEvent.VK_DOWN || button == KeyEvent.VK_S) {
      dy = 0;
    }
  }

  public boolean isOutOfBoundsLeft() {
    if (this.x <= 0) {
      return true;
    }
    return false;
  }

  public boolean isOutOfBoundsRight() {
    if (this.x + this.w >= this.maxX) {
      return true;
    }
    return false;
  }

  public boolean isOutOfBoundsUp() {
    if (this.y <= this.movementBoundY) {
      return true;
    }
    return false;
  }

  public boolean isOutOfBoundsDown() {
    if (this.y + this.h >= this.maxY) {
      return true;
    }
    return false;
  }
}
