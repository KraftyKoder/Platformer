import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Image;

public class Player extends CollisionDetector {

  int lives = 3;
  boolean isJumping = false;
  long jumpStartTime;
  int jumpInitDy;
  ImageIcon playerII = new ImageIcon("Player.png");
  Image playerImage = playerII.getImage();

  public Player(int w, int h, int maxX, int maxY) {
    this.w = w;
    this.h = h;
    this.maxX = maxX;
    this.maxY = maxY;
    this.playerImage = this.playerImage.getScaledInstance(w, h, 1);
  }

  public void display(Graphics2D gameGraphics, Game game) {
    gameGraphics.drawImage(playerImage, x, y, game);
  }

  public void move() {
    x += dx;
    y += dy;
  }

  public void jump(long time, PlayerPlatform platform) {
    dy = (int) (jumpInitDy + 0.01 * (time - jumpStartTime));
    if (y + h + dy >= platform.y + platform.dy && y + h <= platform.y
        && (x + w >= platform.x && x <= platform.x + platform.w)) {
      isJumping = false;
      dy = 0;
      y = platform.y - h;
      platform.speed = 5;
    }
  }

  public boolean isOutOfBounds() {
    if (x <= 0 || x + w >= maxX || y <= 0 || y + h >= maxY) {
      return true;
    }
    return false;
  }
}
