import java.awt.Graphics2D;
import java.awt.Color;

public class Level {

  int[] obsXPos;
  int[] obsYPos;
  int[] obsW;
  int[] obsH;
  int levelNum;
  int numObstacles;
  Obstacle[] levelObstacles;
  int finishX;
  int finishY;
  int finishW;
  int finishH;
  Obstacle finishLine;

  public Level(int levelNum, int numObstacles,
               int[] obsXPos, int[] obsYPos, int[] obsW, int[] obsH,
               int finishX, int finishY, int finishW, int finishH) {
    this.levelNum = levelNum;
    this.numObstacles = numObstacles;
    this.obsXPos = obsXPos;
    this.obsYPos = obsYPos;
    this.obsW = obsW;
    this.obsH = obsH;
    this.levelObstacles = new Obstacle[this.numObstacles];
    for (int i = 0; i < this.numObstacles; i++) {
      this.levelObstacles[i] = new Obstacle();
    }

    this.finishX = finishX;
    this.finishY = finishY;
    this.finishW = finishW;
    this.finishH = finishH;
    this.finishLine = new Obstacle();

    resetEntities();

    for (int i = 0; i < this.numObstacles; i++) {
      this.levelObstacles[i].initGradColor();
    }
    finishLine.obsColor = new Color(255, 200, 100, 255);
  }

  public void resetEntities() {
    for (int i = 0; i < this.numObstacles; i++) {
      this.levelObstacles[i].x = this.obsXPos[i];
      this.levelObstacles[i].y = this.obsYPos[i];
      this.levelObstacles[i].w = this.obsW[i];
      this.levelObstacles[i].h = this.obsH[i];
    }
    this.finishLine.x = this.finishX;
    this.finishLine.y = this.finishY;
    this.finishLine.w = this.finishW;
    this.finishLine.h = this.finishH;
  }

  public void display(Graphics2D gameGraphics, Game game) {
    for (Obstacle obs : this.levelObstacles) {
      obs.display(gameGraphics, game);
    }
    finishLine.display(gameGraphics, game);
  }

  public void move() {
    for (Obstacle obs : this.levelObstacles) {
      obs.move();
    }
    this.finishLine.move();
  }
}
