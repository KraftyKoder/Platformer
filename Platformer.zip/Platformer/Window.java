import javax.swing.JFrame;

public class Window extends JFrame {

  int sizeX = 960;
  int sizeY = 540;


  public Window() {
    init();
  }

  public void init() {
    setSize(sizeX, sizeY);
    setResizable(false);
    setTitle("Platformer");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);

    Game gamePanel = new Game(sizeX, sizeY);
    add(gamePanel);
    Thread gameThread = new Thread(gamePanel);
    gameThread.start();
  }

  public static void main(String[] args) {
    Window gameWindow = new Window();
    gameWindow.setVisible(true);
  }
}
