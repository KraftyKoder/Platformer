import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Image;

public class Game extends JPanel implements Runnable {

  int maxX;
  int maxY;
  Player player;
  PlayerPlatform playerPlatform;
  String gamePhase = "start";
  int currentLevel = 1;
  Level[] levels;
  int frameSpeed = 20;
  int score;

  ImageIcon titleII = new ImageIcon("Title.png");
  Image titleImage = titleII.getImage();

  ImageIcon gameOverII = new ImageIcon("GameOver.png");
  Image gameOverImage = gameOverII.getImage();

  ImageIcon victoryII = new ImageIcon("Victory.png");
  Image victoryImage = victoryII.getImage();

  public Game(int windowSizeX, int WindowSizeY) {
    this.maxX = windowSizeX;
    this.maxY = WindowSizeY - 30;
    init();
  }

  public void init() {
    setBackground(Color.BLACK);
    addKeyListener(new KeyInputReader());
    setFocusable(true);
    player = new Player(10, 10, maxX, maxY);
    playerPlatform = new PlayerPlatform(50, 10, player);
    initLevels();

    titleImage = titleImage.getScaledInstance(maxX * 4 / 5, -1, 1);
    gameOverImage = gameOverImage.getScaledInstance(maxX * 2 / 5, -1, 1);
    victoryImage = victoryImage.getScaledInstance(maxX * 3 / 5, -1, 1);
    setFont(new Font("Monospaced", 1, maxX / 48));
  }

  public void initLevels() {
    this.levels = new Level[1];
    initLevelOne();
  }

  public void initLevelOne() {
    int gapSize = 20;
    int[] xPos = {maxX, maxX + 250, maxX + 250, maxX + 500,
                  maxX + 800, maxX + 900, maxX + 1000, maxX + 1100, maxX + 1200, maxX + 1000,
                  maxX + 1300, maxX + 1350, maxX + 1500, maxX + 1650, maxX + 1700, maxX + 1500,
                  maxX + 2000, maxX + 2140, maxX + 2140, maxX + 2280,
                  maxX + 2800, maxX + 2900, maxX + 2900, maxX + 3000, maxX + 3000,
                  maxX + 3600, maxX + 3800, maxX + 4000};
    int[] yPos = {0, maxY / 2, maxY * 3 / 4 + gapSize, 0,
                  maxY * 4 / 5, maxY * 3 / 5, maxY * 2 / 5, maxY * 3 / 5, maxY * 4 / 5, maxY * 2 / 5 + 65 + gapSize,
                  maxY / 5 - 40, maxY * 2 / 5, maxY * 2 / 5, maxY * 2 / 5, maxY / 5 - 40, maxY * 2 / 5 + 85 + gapSize,
                  maxY / 5, 0, maxY / 2 + gapSize + 10, maxY / 5,
                  maxY / 2 - 50, maxY / 2 - 125, maxY / 2 + 50, maxY / 2 - 175, maxY / 2 + 125,
                  maxY / 3, maxY / 3, maxY / 3};
    int[] w = {50, 50, 50, 50,
               40, 40, 40, 40, 40, 40,
               40, 40, 40, 40, 40, 40,
               30, 30, 30, 30,
               500, 300, 300, 100, 100,
               40, 40, 40};
    int[] h = {maxY * 3 / 5, maxY / 4, maxY / 4 - gapSize, maxY * 3 / 5,
               80, 40, 65, 40, 80, maxY * 3 / 5 - 65 - 3 * gapSize / 2,
               80, 40, 85, 40, 80, maxY * 3 / 5 - 85 - 2 * gapSize,
               maxY * 3 / 5, maxY / 2 - gapSize - 10, maxY / 2 - gapSize - 10, maxY * 3 / 5,
               100, 75, 75, 50, maxY / 2 - 125 - gapSize + 10,
               maxY / 3, maxY / 3, maxY / 3};
    levels[0] = new Level(1, xPos.length, xPos, yPos, w, h,
                               maxX + 4400, 0, 30, maxY);

    int oscA = maxY / 3 * frameSpeed;
    int oscT = 3000;
    levels[0].levelObstacles[25].movingY = true;
    levels[0].levelObstacles[25].A = -1 * oscA;
    levels[0].levelObstacles[25].T = oscT;
    levels[0].levelObstacles[26].movingY = true;
    levels[0].levelObstacles[26].A = oscA;
    levels[0].levelObstacles[26].T = oscT;
    levels[0].levelObstacles[27].movingY = true;
    levels[0].levelObstacles[27].A = -1 * oscA;
    levels[0].levelObstacles[27].T = oscT;
  }

  public void paintComponent(Graphics graphics) {
    super.paintComponent(graphics);
    if (gamePhase == "start") {
      start(graphics);
    } else if (gamePhase == "playing") {
      drawScene(graphics);
    } else if (gamePhase == "end" && player.lives == 0) {
      gameOver(graphics);
    } else {
      victory(graphics);
    }
  }

  public void start(Graphics graphics) {
    Graphics2D gameGraphics = (Graphics2D) graphics;
    gameGraphics.setColor(Color.WHITE);
    gameGraphics.drawImage(titleImage, maxX / 10, maxY / 3, this);
    gameGraphics.drawString(">>> Press Enter To Start <<<", maxX / 3, maxY * 2 / 3);
  }

  public void drawScene(Graphics graphics) {
    Graphics2D gameGraphics = (Graphics2D) graphics;
    gameGraphics.setColor(new Color(100, 100, 100, 100));
    gameGraphics.fillRect(0, playerPlatform.movementBoundY - 1, maxX, 2);
    this.levels[currentLevel - 1].display(gameGraphics, this);
    player.display(gameGraphics, this);
    playerPlatform.display(gameGraphics, this);
    gameGraphics.setColor(Color.WHITE);
    gameGraphics.drawString("LIVES: " + player.lives, maxX - 110, 25);
  }

  public void gameOver(Graphics graphics) {
    Graphics2D gameGraphics = (Graphics2D) graphics;
    gameGraphics.setColor(Color.WHITE);
    gameGraphics.drawImage(gameOverImage, maxX * 3 / 10, maxY / 4, this);
    gameGraphics.drawString(">>> Press Enter To Try Again <<<",
                            maxX * 29 / 96, maxY * 4 / 5);
  }

  public void victory(Graphics graphics) {
    Graphics2D gameGraphics = (Graphics2D) graphics;
    gameGraphics.setColor(Color.WHITE);
    gameGraphics.drawImage(victoryImage, maxX / 5, maxY / 3, this);
    gameGraphics.drawString("SCORE: " + score, maxX * 17 / 40, maxY * 15 / 24);
    gameGraphics.drawString(">>> Press Enter To Play Again <<<",
                            maxX * 7 / 24, maxY * 3 / 4);
  }

  public void reset() {
    player.x = maxX / 2 - player.w / 2;
    player.y = maxY * 3 / 4 - player.h / 2;
    player.isJumping = false;
    playerPlatform.w = 50;
    playerPlatform.x = player.x + player.w / 2 - playerPlatform.w / 2;
    playerPlatform.y = player.y + player.h;
    playerPlatform.speed = 5;
    this.levels[currentLevel - 1].resetEntities();
  }

  public void run() {
    long platformCollisionTime = System.currentTimeMillis();
    while(true) {
      if (gamePhase == "playing") {
        if (player.isJumping) {
          player.jump(System.currentTimeMillis(), playerPlatform);
        }
        playerPlatform.move();
        player.move();
        levels[currentLevel - 1].move();
        if (player.collision(this.levels[currentLevel - 1].levelObstacles) ||
            player.isOutOfBounds()) {
          try {
            Thread.sleep(750);
          } catch (InterruptedException e) {}
          player.lives--;
          if (player.lives > 0) {
            reset();
          } else {
            gamePhase = "end";
          }
        }
        if (playerPlatform.collision(levels[currentLevel - 1].levelObstacles) &&
            playerPlatform.w > 20 &&
            System.currentTimeMillis() - platformCollisionTime >= 2000) {
          playerPlatform.w -= 10;
          playerPlatform.x += 5;
          platformCollisionTime = System.currentTimeMillis();
          if ((player.x > playerPlatform.x + playerPlatform.w ||
               player.x + player.w < playerPlatform.x) && !player.isJumping) {
            player.jumpStartTime = System.currentTimeMillis();
            player.isJumping = true;
            player.jumpInitDy = -4;
            player.dx = 0;
            playerPlatform.speed = 7;
          }
        }
        if (player.collision(levels[this.currentLevel - 1].finishLine)) {
          gamePhase = "end";
          score = player.lives * 1000 + playerPlatform.w * 10;
        }
      }
      try {
        Thread.sleep(frameSpeed);
      } catch (InterruptedException e) {}
      repaint();
    }
  }

  private class KeyInputReader extends KeyAdapter {
    public void keyPressed(KeyEvent k) {
      int button = k.getKeyCode();
      if (gamePhase == "playing") {
        playerPlatform.keyPressed(button);
      } else if (button == KeyEvent.VK_ENTER) {
        if (gamePhase == "start") {
          player.lives = 3;
          reset();
          gamePhase = "playing";
        } else if (gamePhase == "end") {
          gamePhase = "start";
        }
      }
    }

    public void keyReleased(KeyEvent k) {
      int button = k.getKeyCode();
      playerPlatform.keyReleased(button);
    }
  }
}
